interface Caller {
    void reply();
}
